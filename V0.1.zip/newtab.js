$(window).bind("load", function() {
	renderNew();
});


var strTopSites="<table id=\"topSitesTable\"><tr>";
var strApps='<table id="appTable"><tr><td><div class="applink"><a href="https://chrome.google.com/webstore" title="Chrome Web Store"><img src="http://cf.wallpaperexplorer.com/ChromeWebstoreIcon.png"></a><div class="appname">Chrome Web Store</div></div></td>';


function renderNew(){
	$("body").show();

	$("#search").click(function(e){
		 showSearch();
	});
	$("#topSites").click(function(e){
		showSpeedDial();
	});
	$("#apps").click(function(e){
		showApps();
	});
	
	$("#imageSearchGo").click(function(e){
		chrome.tabs.update({url: "http://www.google.com/search?q=" + $("#imageSearch").val() + "&tbm=isch"});
	});
	$("#pirateSearchGo").click(function(e){
		chrome.tabs.update({url: "http://thepiratebay.se/search/" + $("#pirateSearch").val() + "/0/7/0"});
	});
	$("#pirateSearchHDTV").click(function(e){
		chrome.tabs.update({url: "http://thepiratebay.se/search/=" + $("#pirateSearch").val() + "/0/7/208"});
	});
	$("#pirateSearchHDMovies").click(function(e){
		chrome.tabs.update({url: "http://thepiratebay.se/search/=" + $("#pirateSearch").val() + "/0/7/207"});
	});
	$("#wikiGo").click(function(e){
		chrome.tabs.update({url: "http://en.wikipedia.org/wiki/" + $("#wiki").val()});
	});
	$("#bingGo").click(function(e){
		//chrome.tabs.update({url: "https://www.google.com/searchq=" + $("#imageSearch").val()});
		var d = new Date();
		var n = d.getSeconds();
		if(n>0 && n<10){
			//barrel roll
			chrome.tabs.update({url: "https://www.google.com/webhp?tab=ww&ei=E6EwU7jBLs6jqwHho4G4CA&ved=0CBoQ1S4#q=do+a+barrel+roll&safe=off"});
		}else if(n>10 && n<20){
			//breakout
			chrome.tabs.update({url: "https://www.google.com/search?q=atari+breakout&safe=off&espv=2&source=lnms&tbm=isch&sa=X&ei=bqEwU9-rGc6gkQeXuYGIBQ&sqi=2&ved=0CAcQ_AUoAQ&biw=1468&bih=685#imgdii=_"});
		}else if(n>20 && n<30){
			//I'm sorry dave...
			chrome.tabs.update({url: "https://www.youtube.com/watch?v=7qnd-hdmgfk"});
		}else if(n>30 && n<40){
			//Google Bing
			chrome.tabs.update({url:"https://www.google.com/webhp?sourceid=chrome-instant&ion=1&espv=2&es_th=1&ie=UTF-8#q=bing&safe=off"});
		}else if(n>40 && n<50){
			//PC Load Letter
			chrome.tabs.update({url:"https://www.youtube.com/watch?v=5QQdNbvSGok"});
		}else if(n>50 && n<60){
			//Zerg Rush
			chrome.tabs.update({url:"https://www.google.com/search?q=zerg+rush&oq=zerg+rush&aqs=chrome.0.69i59j0l5.1804j0j1&sourceid=chrome&es_sm=0&ie=UTF-8"});			
		}else{
			//rick roll
			chrome.tabs.update({url:"https://www.youtube.com/watch?v=oHg5SJYRHA0"});
		}
	});
	$("#imdbGo").click(function(e){
		chrome.tabs.update({url: "http://www.imdb.com/find?q=" + $("#imdb").val() + "&s=all"});
	});
	
	$("#googleLikeABossGo").click(function(e){
		var str="";
		if($("#query").val() != null && $("#query").val() !=""){
			str+=$("#query").val() + ' ';
		}
		if($("#exact").val() != null && $("#exact").val() !=""){
			str+='"' + $("#exact").val() + '" ';
		}
		if($("#exclude").val() != null && $("#exclude").val() !=""){
			str+=parseString($("#exclude").val(),"-");
		}
		if($("#synonyms").val() != null && $("#synonyms").val() !=""){
			str+=parseString($("#exclude").val(),"~");
		}	
		if($("#site").val() != null && $("#site").val() !=""){
			str+='site:' + $("#site").val() + ' ';
		}
		if($("#links").val() != null && $("#links").val() !=""){
			str+='link:' + $("#links").val() + ' ';
		}
		if($("#range").val() != null && $("#range").val() !=""){
			str+=$("#range").val() + ' ';
		}
		if($("#related").val() != null && $("#related").val() !=""){
			str+='related:' + $("#related").val() + ' ';
		}
		if(str.length>0){
			chrome.tabs.update({url: "https://www.google.com/webhp?sourceid=chrome-instant&ion=1&espv=2&es_th=1&ie=UTF-8#q=" + str});
		}
	});	

	//////////////////////////////////////////////////
	$("#advancedGoogle").click(
		function(e){
			if(localStorage["advancedGoogle"] == "true"){
				$(".googleLikeABoss").hide();
				localStorage["advancedGoogle"] = "false";
			}else{
				$(".googleLikeABoss").show();
				localStorage["advancedGoogle"] = "true";	
			}
		}
	);	
	
	

	//Get and populate top sites
	chrome.topSites.get(function(resp){
		var maxLength = resp.length > 8 ? 8 : resp.length;
		for(var i = 0; i < maxLength; i++){
			if(i==4){strTopSites+="</tr><tr>";}
			addSpeedDial(resp[i].title,resp[i].url);
		}
		strTopSites+="</tr></table>";
		$('#speedDial').append(strTopSites);
	});
	
	//Get and populate apps
	chrome.management.getAll(function(resp){
		for(var i = 0; i < resp.length; i++){
			//Not show this app
			if(resp[i].name != "More Better New Tab"){
				addApp(resp[i]);
			}
		}
			strApps+="</tr></table>";
			$('.apps').append(strApps);			
	});

	//Set and save current screen, show last screen
	if(localStorage["currentScreen"] != null){
		if(localStorage["currentScreen"] == "speedDial"){
			showSpeedDial();
		}
		else if(localStorage["currentScreen"]=="apps"){
			showApps();
		}
		else{
			showSearch();
		}
	}else{showSpeedDial();}
	
	$('#history')
        .click(function(e) {
            chrome.tabs.update({
                url: 'chrome://history/'
            });
        });
		
	$('#chromeSettings').click(function(e) {
        chrome.tabs.update({
            url: 'chrome://settings/'
        });
    });
		
	$('#extensions')
        .click(function(e) {
            chrome.tabs.update({
                url: 'chrome://extensions/'
            });
        });
}


function parseString(str, strCharacter) {
    var words = str.split(" ");
    var strNew = "";

    for (var i = 0; i < words.length; i++) {
        if(words[i].substring(0)!=strCharacter){
			strNew += strCharacter + words[i] + " ";
		}
    }

	return strNew;
}


function showSearch(){
	localStorage["currentScreen"] = "search";
	$(".search").show();
	$(".speedDial").hide();
	$(".apps").hide();
	if(localStorage["advancedGoogle"] == "true"){
		$(".googleLikeABoss").show();
	}else{
		$(".googleLikeABoss").hide();
		localStorage["advancedGoogle"] = "false";	
	}	
}

function showSpeedDial(){
	localStorage["currentScreen"] = "speedDial";
	$(".search").hide();
	$(".speedDial").show();
	$(".apps").hide();
}
function showApps(){
	localStorage["currentScreen"] = "apps";
	$(".search").hide();
	$(".speedDial").hide();
	$(".apps").show();
}


function addSpeedDial(name, link){
	if(name.length > 30){
		name = name.substr(0, 27)+"...";
	}
	var thumbnail = "http://free.pagepeeker.com/v2/thumbs.php?size=l&url=" +link;
	thumbnail = "http://chromeutils.appspot.com/t/?url=" + escape(link);
	strTopSites+='<td><div class="speedDialLink"><a href="'+link+'"><img class=speedDialLink" src="' + thumbnail + '"></a></br><div class="sdname">'+name+'</div></div></td>';
}

function addApp(app){
	//Add app to screen
	if(app.icons && app.isApp){
		if(app.name.length > 23){
			app.shortname = app.name.substr(0, 20)+"...";
		}
		else{
			app.shortname = app.name;
		}
		strApps+='<td><div class="applink"><a href="'+app.appLaunchUrl+'" title="'+app.name+'"><img src="'+app.icons[app.icons.length-1].url+'"></a><div class="appname">'+app.shortname+'</div></div></td>';
	}
}
